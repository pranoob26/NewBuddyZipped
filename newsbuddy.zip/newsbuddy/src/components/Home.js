import React from "react";
import Headline from "./Headline";
function Home() {
  return (
    <div>
      <div className="my-5 text-2xl ml-44 ">Headlines</div>
      <Headline topic="Headline"></Headline>
    </div>
  );
}

export default Home;
