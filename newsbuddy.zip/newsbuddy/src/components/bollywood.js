import React from "react";
import Headline from "./Headline";
function bollywood() {
  return (
    <div>
      <div className="my-5 text-2xl ml-44 ">Bollywood Headlines</div>
      <Headline topic="bollywood"></Headline>
    </div>
  );
}

export default bollywood;
