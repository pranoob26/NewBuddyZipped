import React from "react";
import Headline from "./Headline";
function Finance() {
  return (
    <div>
      <div className="my-5 text-2xl ml-44 ">Finance News</div>
      <Headline topic="finance"></Headline>
    </div>
  );
}

export default Finance;
