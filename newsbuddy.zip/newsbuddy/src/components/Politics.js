import React from "react";
import Headline from "./Headline";
function Politics() {
  return (
    <div>
      <div className="my-5 text-2xl ml-44 ">Politics News</div>
      <Headline topic="Politics"></Headline>
    </div>
  );
}

export default Politics;
